@echo off
title H P M S & Associates - Practice Management System
echo ============================================================
echo      H P M S & Associates - Practice Management System
echo ============================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not found in system PATH.
    echo Please install Python 3.9+ and try again.
    pause
    exit /b 1
)

echo [1/2] Checking and installing dependencies...
pip install -r requirements.txt

echo.
echo [2/2] Launching Practice Management System...
echo Opening in browser at http://localhost:8501
echo.
echo ============================================================
echo Press Ctrl+C to stop the application server.
echo ============================================================
echo.

streamlit run app.py

pause
